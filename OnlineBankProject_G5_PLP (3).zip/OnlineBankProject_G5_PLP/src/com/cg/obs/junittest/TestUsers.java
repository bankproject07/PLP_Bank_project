package com.cg.obs.junittest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.obs.bean.Admin;
import com.cg.obs.bean.Users;

public class TestUsers {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetUserId() 
		{
			Users users= new Users(12345,"abcd");
			assertEquals(users.getUserId(), 12345);
		}
	

	@Test
	public void testGetLoginPassword() 
	{
		Users users= new Users(12345,"abcd");
		assertEquals(users.getLoginPassword(),"abcd");
	}

}
