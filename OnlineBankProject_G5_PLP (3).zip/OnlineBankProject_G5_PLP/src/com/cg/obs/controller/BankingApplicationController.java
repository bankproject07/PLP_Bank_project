package com.cg.obs.controller;


import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.cg.obs.bean.Customer;
import com.cg.obs.bean.Transactions;
import com.cg.obs.bean.Users;
import com.cg.obs.service.IUserService;



@Controller
@SessionAttributes("accountid")

public class BankingApplicationController {

	
	@Autowired
	IUserService userService;
	
	public BankingApplicationController() {
		// TODO Auto-generated constructor stub
	}

	public IUserService getUserService() {
		return userService;
	}

	public void setUserService(IUserService userService) {
		this.userService = userService;
	}

	public BankingApplicationController(IUserService userService) {
		super();
		this.userService = userService;
	}
	
	
	@RequestMapping("Login")
	public String getLoginPage(@RequestParam("username") int userId,@RequestParam("password") String password,Model model,HttpSession session){
		
		System.out.println(userId+" "+password);
		Users user=userService.getUser(userId);
		System.out.println(user);
		if(user!=null)
		{
			
			
		if(password.equalsIgnoreCase(user.getLoginPassword()))
		{
			System.out.println("user login success");
		      //model.addAttribute("accountno", user.getAccountId());
		session.setAttribute("accountno", user.getAccountId());
			return "index";
		}
		
		
	}
		model.addAttribute("errMsg", "Login error");
			return "pages/ErrorPage";
			
		
	
	}
	
	@RequestMapping("GetMiniTransactions")
	public String getMiniTransactionPage(Model model,HttpSession session){
		
		System.out.println(session.getAttribute("accountno"));
		Long accountno=(Long)session.getAttribute("accountno");
		//System.out.println(accid);
		//Long accountno=Long.parseLong(accid);
		List<Transactions> miniTransList=userService.getMiniTransactions(accountno);
		model.addAttribute("miniTrasactionList",miniTransList);
		
		return "pages/MiniTransactions";
	}
	
	@RequestMapping("GetDetailedTrasactions")
	public String getDetailedTransactionsPage() {
		
		
		return "GetCustomerpage";
	}

	
	
}
